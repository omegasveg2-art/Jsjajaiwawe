// aim assist: target pick (pure, host-testable) + closed-loop controller that turns angle error into virtual-finger px.
#pragma once
#include "game.h"

struct AimCfg {
    bool on = false;
    int key = 1;                 // 0 always, 1 hold Vol-Down, 2 hold Vol-Up
    int mode = 0;                // 0 smooth, 1 snap
    float fovPx = 180.f;         // circle radius around screen centre
    float smooth = 0.25f;        // fraction of the angular error corrected per game frame (smooth mode)
    float ppd = 9.f;             // starting guess: touch px per degree (learned online afterwards)
    float maxStep = 40.f;        // px per step cap
    int bone = 0;                // 0 head, 1 body, 2 legs
    bool invY = false;
    float sx = 0.62f, sy = 0.40f;    // where the virtual finger starts (fraction of screen)
    float W = 2400.f, H = 1080.f;    // logical screen
    int rot = 1;                     // Surface rotation 0..3
    float fovScale = 1.f;
    bool fovHoriz = false;
    bool teamCheck = true;
    float maxDist = 150.f;
    float leadMs = 0.f;             // target lead (velocity * lead)
    bool noRecoil = false, noSpread = false;   // weapon parameter patches (see Game::patch_weapons)
    bool infAmmo = false, wallbang = false;    // see Game::patch_arms
    bool silent = false;                       // FireRay/FirePellets detour (see SilentHook)
    int silentKey = 0;                         // 0 always, 1 hold Vol-Down, 2 hold Vol-Up (independent of the aimbot key)
    float silentFov = 260.f;                   // px around the crosshair in which a silent target is accepted
    MoveCfg mv;                                // movement patches (see Game::patch_move)
    bool trig = false;                         // auto fire: virtual finger on the fire button while an enemy is under the crosshair
    float trigPx = 28.f, trigMs = 30.f;        // hit radius around the crosshair (px) and reaction delay
    float fireX = 0.92f, fireY = 0.65f;        // fire button position (fraction of the screen)
};

struct AimOut {
    bool has = false;
    int actor = 0;
    Vec3 point, dir;             // world target point and unit direction from the camera
    float dyaw = 0, dpitch = 0;  // degrees the camera still has to turn (right / up positive)
    float errDeg = 0;
};

Vec3 bone_point(const PlayerInfo& p, int bone, float leadSec);
AimOut aim_step(const Snapshot& s, const AimCfg& c, int stickyActor);

// One step per game frame. Subtracts what is still "in flight" (px sent, not yet visible in the camera) and
// learns the signed px/degree gain of both axes from how the camera actually responded.
struct AimCtl {
    float ppdX = 0, ppdY = 0;                       // signed px per degree, learned
    bool step(const AimOut& a, const AimCfg& c, double t, float& dx, float& dy);
    bool observe(float yawDeg, float pitchDeg, bool injecting);   // returns true when the camera changed
    void idle();                                    // no target: forget in-flight state
private:
    float cfgPpd_ = -1, h0x_ = 0, h0y_ = 0, h1x_ = 0, h1y_ = 0;
    float wPx_ = 0, wPy_ = 0, wYaw_ = 0, wPit_ = 0;
    double winStart_ = 0;
    bool have_ = false;
    float lastYaw_ = 0, lastPitch_ = 0;
};
