// CounterFlame state reader: one call = one consistent-enough snapshot for the ESP.
#pragma once
#include "code.h"
#include "il2cpp.h"
#include "vmath.h"
#include <map>
#include <string>
#include <vector>

struct PlayerInfo {
    int actor = 0;
    Vec3 pos;                 // feet, world (rendered position when the Transform walk validated, else network position minus interpolation lag)
    Vec3 vel;
    float yaw = 0;            // degrees, Unity convention (0 = +Z, clockwise from above)
    bool local = false, dead = false, crouch = false;
    bool mate = false;        // listed by the game's own TeammateLabels (works even when the life table is not found)
    bool exact = false;       // position comes from the rendered Transform (validated), not the network sample
    int hp = 100;
    uint8_t team = 0;         // 0 none, 1 CT, 2 T, 3 spec (LifeState.Team*)
    char name[32] = {0};
};

struct BombInfo {
    int state = 0;            // 0 none, 1 carried (owner = actor), 2 planted and ticking
    bool hasPos = false;
    Vec3 pos;
    float remaining = -1.f;   // seconds to detonation (server clock), -1 unknown
    int owner = 0;            // actor id of the carrier / planter
};

struct Snapshot {
    BombInfo bomb;
    bool valid = false;       // camera + player list readable
    Cam cam;
    bool haveLocal = false;
    int localActor = 0;
    uint8_t localTeam = 0;
    bool lifeOk = false;      // hp/team table found
    std::vector<PlayerInfo> players;
};

struct MoveCfg {
    bool bhop = false;            // auto-hop + no bunny-hop speed cap + no stamina penalty, and a horizontal speed floor while moving
    float bhopSpeed = 9.f;        // m/s: horizontal speed floor while bhop is on and the stick is held (0 = only remove the caps)
    bool fly = false;             // free flight along the camera: velocity is driven, gravity off
    float flySpeed = 10.f;        // m/s
    bool noclip = false;          // the game's own NoclipEnabled flag
    float speed = 1.f;            // walking speed multiplier (tuning MaxSpeed + horizontal velocity on the ground)
    float jump = 1.f, grav = 1.f; // jump impulse (MovementConVars) / gravity scale
    bool infStamina = false, noFall = false, noWeaponSlow = false;
    float airStrafe = 1.f;        // multiplier of AirAccelerate / AirWishSpeedCap (strafe control in the air)
    bool any() const { return infStamina || noFall || noWeaponSlow || airStrafe > 1.001f || bhop || fly || noclip || speed != 1.f || jump != 1.f || grav != 1.f; }
};

class Game {
public:
    Game(IMem& m, uint64_t il2cppBase) : m_(m), il_(m, il2cppBase) {}
    bool resolve();                 // class pointers; false until the game reached a state where they exist
    bool update(Snapshot& s);
    const char* status() const { return status_.c_str(); }
    int classes_seen() const { return il_.classes_seen(); }
    void set_scan_gap(double s) { il_.set_scan_gap(s); }
    // weapon parameter patches (managed floats of WeaponParameters / RecoilParameters); throttled, reversible
    void patch_weapons(bool noRecoil, bool noSpread);
    void drive_move(const MoveCfg& c, const Snapshot& s);   // every loop: bhop / speed / fly / noclip on the LOCAL PlayerMovement; reversible
    int move_patched() const { return (int)mv_.size(); }
    std::string move_diag() const { return mvDiag_; }
    std::string arms_diag() const { return armsDiag_; }
    std::string local_diag() const;                 // which local objects were found (ctrl / movement / arms)
    // code patches (ret on ApplyCameraRecoil / AddShootKick / Shake / GetRelativeDispertion) + arms state (ammo, wallbang mask)
    void patch_code(bool noRecoil, bool noSpread);
    void patch_arms(bool infAmmo, bool wallbang, bool noRecoil);
    int code_patched() const { return (int)code_.count(); }
    // silent aim: install/remove the detours, and per tick feed the direction (on=false -> normal shots)
    void silent_prepare(bool wanted);
    void silent_feed(bool on, Vec3 dir);
    const char* silent_status() const { return silentStatus_.c_str(); }
    uint32_t silent_hits() { return shotsArmed_; }              // shots fired while the detour was armed
    int tx_ok() const { return txOk_; }
    int tx_bad() const { return txBad_; }
    void shutdown_patches();                        // restore everything we changed (called on exit / game close)
    int patched() const { return (int)saved_.size(); }
    int weapons() const { return (int)wp_.size(); }
private:
    bool find_life();
    bool find_local();                              // PlayerController of the local player (PhotonView.IsMine) by heap scan: does not depend on PlayerCulling.Instances
    bool world_pos(uint64_t transform, Vec3& out);  // managed Transform -> world position through Unity's native TransformHierarchy (validated by the caller)
    uint64_t kCtrl_ = 0, localCtrl_ = 0;
    double nextLocalScan_ = 0;
    uint64_t kTun_ = 0, kCore_ = 0, kConv_ = 0;
    int txOk_ = 0, txBad_ = 0, txFail_ = 0;
    double txOffUntil_ = 0;
    bool find_bomb();
    void read_bomb(Snapshot& s, double serverTime);
    bool comp_world_pos(uint64_t component, Vec3& out);   // managed Component -> native GameObject -> first component (Transform) -> world position
    bool world_pos_nat(uint64_t nativeTransform, Vec3& out);
    uint64_t kBM_ = 0, kBomb_ = 0, bm_ = 0;
    double nextBm_ = 0;
    bool find_labels();
    uint64_t kLabels_ = 0, labels_ = 0;
    double nextLabelsScan_ = 0;
    IMem& m_;
    Il2 il_;
    uint64_t kCull_ = 0, kFps_ = 0, kLife_ = 0;
    uint64_t cullStatics_ = 0, fpsStatics_ = 0;
    uint64_t life_ = 0;             // LifeState instance
    double nextLifeScan_ = 0;
    std::string status_ = "init";
    struct Saved { uint64_t addr; uint32_t bits; int cat; uint64_t obj; uint64_t klass; };   // restore only while obj still starts with the same klass word
    std::vector<Saved> saved_;
    std::vector<uint64_t> wp_;
    uint64_t kWp_ = 0, kMove_ = 0, localMove_ = 0, mvOwner_ = 0;
    struct MvSaved { int size; uint32_t bits; uint64_t obj; uint64_t klass; };   // obj/klass: only write back while that object is still alive
    std::map<uint64_t, MvSaved> mv_;
    std::string mvDiag_, armsDiag_;
    float baseMax_ = 0;                             // original tuning MaxSpeed (units)
    float hopFloor_ = 0;
    bool tunOk_ = false;
    double nextMv_ = 0, nextCode_ = 0, nextSilent_ = 0;
    uint64_t kArms_ = 0, localArms_ = 0, armsOwner_ = 0;
    int lastWeapon_ = -1, maxMag_ = 0;
    std::map<uint64_t, MvSaved> ar_;
    CodePatcher code_{m_};
    SilentHook fire_{m_, code_}, pell_{m_, code_};
    bool fireOk_ = false, pellOk_ = false;
    uint32_t lastTimeFired_ = 0, shotsArmed_ = 0;
    std::string silentStatus_ = "off";
    uint64_t addrRecoil_ = 0, addrKick_ = 0, addrShake_ = 0, addrDisp_ = 0;
    double nextWp_ = 0, nextWpScan_ = 0;
    bool code_retDone_ = false;
};
