#include "game.h"
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <unordered_map>

static double now_s() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

static bool finite3(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }

bool Game::resolve() {
    if (!kCull_) kCull_ = il_.klass(off::PlayerCulling::cls);
    if (!kFps_)  kFps_  = il_.klass(off::PlayerFPSCamera::cls);
    if (!kLife_) kLife_ = il_.klass(off::LifeState::cls);
    cullStatics_ = il_.statics(kCull_);
    fpsStatics_  = il_.statics(kFps_);
    status_ = !kCull_ ? "no PlayerCulling class (il2cpp structs seen: " + std::to_string(il_.classes_seen()) + ")" : !cullStatics_ ? "PlayerCulling statics null (cctor not run)" : "ok";
    return kCull_ && cullStatics_;
}

// LifeState has no static handle we can reach from a klass slot (it hangs off the PlayerLife singleton),
// so locate the instance by scanning for objects whose first word is the LifeState klass.
bool Game::find_life() {
    if (!kLife_) return false;
    auto valid = [&](uint64_t o) {
        uint64_t items; uint32_t n;
        if (rdp(m_, o) != kLife_) return false;
        if (!il_.list(rdp(m_, o + off::LifeState::_entries), items, n, 64)) return false;
        return n > 0;
    };
    uint64_t best = 0; uint32_t bestN = 0;
    for (uint64_t o : il_.find_instances(kLife_, valid)) {
        uint64_t items; uint32_t n;
        il_.list(rdp(m_, o + off::LifeState::_entries), items, n, 64);
        if (n >= bestN) { best = o; bestN = n; }
    }
    life_ = best;
    return life_ != 0;
}

// TeammateLabels (HUD) keeps `_mates`: the game's own list of teammates. Used as a second source for the teammate check.
bool Game::find_labels() {
    if (!kLabels_) kLabels_ = il_.klass(off::TeammateLabels::cls);
    if (!kLabels_) return false;
    auto valid = [&](uint64_t o) { uint64_t items; uint32_t n; return rdp(m_, o) == kLabels_ && il_.list(rdp(m_, o + off::TeammateLabels::_mates), items, n, 64); };
    uint64_t best = 0;
    for (uint64_t o : il_.find_instances(kLabels_, valid)) best = o;
    labels_ = best;
    return labels_ != 0;
}

// The local player's PlayerController: PhotonView.IsMine. PlayerCulling.Instances is a culling list and need not contain us,
// so everything that acts on "me" (movement, arms, team) is anchored here instead.
bool Game::find_local() {
    if (!kCtrl_) kCtrl_ = il_.klass(off::PlayerController::cls);
    if (!kCtrl_) return false;
    auto valid = [&](uint64_t o) {
        uint64_t v = rdp(m_, o + off::PlayerController::_view);
        if (!plausible_ptr(v) || rd8(m_, v + off::PhotonView::IsMine) == 0) return false;
        return plausible_ptr(rdp(m_, o + off::PlayerController::_movementController));
    };
    uint64_t best = 0;
    for (uint64_t o : il_.find_instances(kCtrl_, valid)) best = o;
    localCtrl_ = best;
    return best != 0;
}

// Unity native Transform -> world position (64-bit Unity 2019-2022 layout): managed +0x10 = native Transform; +0x38 = hierarchy, +0x40 = index;
// hierarchy +0x18 = TRS array (48 bytes each: pos, rot, scale), +0x20 = parent indices. Callers validate the result against the network position.
bool Game::world_pos(uint64_t tr, Vec3& out) {
    return world_pos_nat(rdp(m_, tr + 0x10), out);
}

bool Game::world_pos_nat(uint64_t nat, Vec3& out) {
    if (!plausible_ptr(nat)) return false;
    uint64_t hier = rdp(m_, nat + 0x38);
    int idx = (int)rd32(m_, nat + 0x40);
    if (!plausible_ptr(hier) || idx < 0 || idx > 200000) return false;
    uint64_t list = rdp(m_, hier + 0x18), par = rdp(m_, hier + 0x20);
    if (!plausible_ptr(list) || !plausible_ptr(par)) return false;
    float t[12];
    if (!m_.read(list + 0x30ull * (uint64_t)idx, t, sizeof t)) return false;
    Vec3 r{t[0], t[1], t[2]};
    int cur = (int)rd32(m_, par + 4ull * (uint64_t)idx);
    for (int g = 0; cur >= 0 && g < 64; g++) {
        if (cur > 200000 || !m_.read(list + 0x30ull * (uint64_t)cur, t, sizeof t)) return false;
        Vec3 q{t[4], t[5], t[6]};
        float w = t[7];
        Vec3 sv{r.x * t[8], r.y * t[9], r.z * t[10]};
        Vec3 c1 = cross(q, sv);
        Vec3 c2 = cross(q, c1 + sv * w);
        r = Vec3{t[0], t[1], t[2]} + sv + c2 * 2.f;
        cur = (int)rd32(m_, par + 4ull * (uint64_t)cur);
    }
    if (!finite3(r)) return false;
    out = r;
    return true;
}


// ---- bomb: BombManager (singleton object) -> Bomb. Position through the native GameObject chain (validated by the caller), timer from the server clock.
bool Game::find_bomb() {
    if (!kBM_) kBM_ = il_.klass(off::BombManager::cls);
    if (!kBM_) return false;
    uint64_t best = 0;
    for (uint64_t o : il_.find_instances(kBM_, [&](uint64_t a) { return rdp(m_, a) == kBM_; })) best = o;
    bm_ = best;
    return bm_ != 0;
}

bool Game::comp_world_pos(uint64_t comp, Vec3& out) {
    uint64_t nat = rdp(m_, comp + 0x10);                        // UnityEngine.Object.m_CachedPtr
    if (!plausible_ptr(nat)) return false;
    uint64_t go = rdp(m_, nat + 0x30);                          // Component.m_GameObject
    if (!plausible_ptr(go)) return false;
    uint64_t arr = rdp(m_, go + 0x30);                          // GameObject component pairs {typeIndex, Component*}
    if (!plausible_ptr(arr)) return false;
    return world_pos_nat(rdp(m_, arr + 0x8), out);              // the Transform is always the first component
}

void Game::read_bomb(Snapshot& s, double serverTime) {
    s.bomb = BombInfo();
    if (!kBM_) kBM_ = il_.klass(off::BombManager::cls);
    if (!kBM_) return;
    if (!(bm_ && rdp(m_, bm_) == kBM_)) {
        bm_ = 0;
        if (now_s() < nextBm_) return;
        nextBm_ = now_s() + 4.0;                                // heap scan: throttled
        if (!find_bomb()) return;
    }
    const bool planted = rd8(m_, bm_ + off::BombManager::_plantedThisRound) != 0;
    const bool over = rd8(m_, bm_ + off::BombManager::_defusedThisRound) != 0 || rd8(m_, bm_ + off::BombManager::_detonatedThisRound) != 0;
    const int owner = (int)rd32(m_, bm_ + off::BombManager::_bombOwnerId);
    uint64_t bomb = rdp(m_, bm_ + off::BombManager::_bomb);
    if (!kBomb_) kBomb_ = il_.klass(off::Bomb::cls);
    const bool bombOk = kBomb_ && plausible_ptr(bomb) && rdp(m_, bomb) == kBomb_ && rd8(m_, bomb + off::Bomb::_isActive) != 0;
    if (planted && !over && bombOk) {
        s.bomb.state = 2;
        s.bomb.owner = owner;
        double ex = 0; m_.read(bomb + off::Bomb::_explodeAt, &ex, 8);
        if (serverTime > 1.0 && std::isfinite(ex)) {
            double rem = ex - serverTime;
            if (rem > -1.0 && rem < 120.0) s.bomb.remaining = (float)std::max(0.0, rem);
        }
        Vec3 p;
        if (rd8(m_, bomb + off::Bomb::_blastPosition) != 0) { p = rdv<Vec3>(m_, bomb + off::Bomb::_blastPosition + 4); if (finite3(p)) { s.bomb.pos = p; s.bomb.hasPos = true; } }
        if (!s.bomb.hasPos && comp_world_pos(bomb, p) && finite3(p) && len(p - s.cam.pos) < 800.f) { s.bomb.pos = p; s.bomb.hasPos = true; }
    } else if (!planted && owner > 0) {
        s.bomb.state = 1; s.bomb.owner = owner;
    }
}

bool Game::update(Snapshot& s) {
    s.valid = false; s.haveLocal = false; s.localActor = 0; s.localTeam = 0; s.lifeOk = false;
    s.players.clear();
    if (!cullStatics_ && !resolve()) return false;

    // --- camera (statics of PlayerCulling are refreshed by the game every frame)
    Vec3 pos = rdv<Vec3>(m_, cullStatics_ + off::PlayerCulling::s__cameraPosition);
    Vec3 fwd = rdv<Vec3>(m_, cullStatics_ + off::PlayerCulling::s__cameraForward);
    bool hasCam = rd8(m_, cullStatics_ + off::PlayerCulling::s__hasCamera) != 0;
    float fl = len(fwd);
    if (!hasCam || !finite3(pos) || !finite3(fwd) || fl < 0.9f || fl > 1.1f) { status_ = "no camera"; return false; }
    s.cam.pos = pos; s.cam.fwd = fwd;
    float fov = 0;
    if (fpsStatics_) {
        uint64_t loc = rdp(m_, fpsStatics_ + off::PlayerFPSCamera::s_Local);
        if (plausible_ptr(loc)) fov = rdf(m_, loc + off::PlayerFPSCamera::BaseFieldOfView);
    }
    s.cam.fovY = (fov > 20.f && fov < 140.f) ? fov : 60.f;

    // --- local player (independent of PlayerCulling.Instances)
    if (!kCtrl_) kCtrl_ = il_.klass(off::PlayerController::cls);
    {
        bool ok = false;
        if (kCtrl_ && localCtrl_ && rdp(m_, localCtrl_) == kCtrl_) {
            uint64_t v = rdp(m_, localCtrl_ + off::PlayerController::_view);
            ok = plausible_ptr(v) && rd8(m_, v + off::PhotonView::IsMine) != 0;
        }
        if (!ok) { localCtrl_ = 0; if (kCtrl_ && now_s() >= nextLocalScan_) { nextLocalScan_ = now_s() + 2.0; find_local(); } }
    }
    int localActorFromCtrl = 0;
    if (localCtrl_) {
        localMove_ = rdp(m_, localCtrl_ + off::PlayerController::_movementController);
        localArms_ = rdp(m_, localCtrl_ + off::PlayerController::_armsController);
        uint64_t v = rdp(m_, localCtrl_ + off::PlayerController::_view);
        if (plausible_ptr(v)) localActorFromCtrl = (int)rd32(m_, v + off::PhotonView::ownerActorNr);
    }

    // --- players
    uint64_t items; uint32_t n;
    if (!il_.list(rdp(m_, cullStatics_ + off::PlayerCulling::s_Instances), items, n, 64)) { status_ = "bad Instances"; return false; }
    uint64_t ptrs[64] = {0};
    if (n && !m_.read(items + il2::ARR_DATA, ptrs, n * 8)) { status_ = "bad Instances array"; return false; }

    // --- hp/team table: actor -> LifeEntry
    std::unordered_map<int, std::pair<int, uint8_t>> life;   // hp, team (+alive folded into hp<=0)
    s.lifeOk = false;
    if (kLife_) {
        uint64_t litems; uint32_t ln;
        bool ok = life_ && rdp(m_, life_) == kLife_ && il_.list(rdp(m_, life_ + off::LifeState::_entries), litems, ln, 64);
        if (!ok && n > 0 && now_s() >= nextLifeScan_) { find_life(); nextLifeScan_ = now_s() + 5.0; }   // heap scan: only in a match, throttled
        if (life_ && rdp(m_, life_) == kLife_ && il_.list(rdp(m_, life_ + off::LifeState::_entries), litems, ln, 64) && ln) {
            std::vector<uint8_t> raw((size_t)ln * off::LifeEntrySize);
            if (m_.read(litems + il2::ARR_DATA, raw.data(), raw.size())) {
                for (uint32_t i = 0; i < ln; i++) {
                    const uint8_t* e = &raw[(size_t)i * off::LifeEntrySize];
                    int actor, hp;
                    memcpy(&actor, e + off::LifeEntry::Actor, 4);
                    memcpy(&hp, e + off::LifeEntry::Health, 4);
                    bool alive = e[off::LifeEntry::Alive] != 0;
                    life[actor] = {alive ? hp : 0, e[off::LifeEntry::Team]};
                }
                s.lifeOk = true;
            }
        }
    }

    // teammates according to the HUD's own list
    std::vector<int> mateActors;
    {
        bool ok = labels_ && rdp(m_, labels_) == kLabels_;
        if (!ok && n > 0 && now_s() >= nextLabelsScan_) { find_labels(); nextLabelsScan_ = now_s() + 5.0; ok = labels_ != 0; }
        uint64_t mi; uint32_t mn;
        if (ok && il_.list(rdp(m_, labels_ + off::TeammateLabels::_mates), mi, mn, 64) && mn) {
            uint64_t arr[64] = {0};
            if (m_.read(mi + il2::ARR_DATA, arr, mn * 8))
                for (uint32_t i = 0; i < mn; i++) {
                    uint64_t mate = untag(arr[i]);
                    if (!plausible_ptr(mate)) continue;
                    uint64_t ct = rdp(m_, mate + off::Mate::Controller), vw = plausible_ptr(ct) ? rdp(m_, ct + off::PlayerController::_view) : 0;
                    if (plausible_ptr(vw)) mateActors.push_back((int)rd32(m_, vw + off::PhotonView::ownerActorNr));
                }
        }
    }

    double serverTime = 0;
    for (uint32_t i = 0; i < n; i++) {
        uint64_t cull = untag(ptrs[i]);
        if (!plausible_ptr(cull)) continue;
        uint64_t ctrl = rdp(m_, cull + off::PlayerCulling::_controller);
        uint64_t net  = rdp(m_, cull + off::PlayerCulling::_network);
        if (!plausible_ptr(ctrl) || !plausible_ptr(net)) continue;
        uint64_t view = rdp(m_, ctrl + off::PlayerController::_view);
        if (!plausible_ptr(view)) continue;

        { double st = 0; m_.read(net + off::PlayerNetwork::_receivedServerTime, &st, 8); if (std::isfinite(st) && st > serverTime) serverTime = st; }
        PlayerInfo p;
        p.local = rd8(m_, view + off::PhotonView::IsMine) != 0;
        if (p.local) { localMove_ = rdp(m_, ctrl + off::PlayerController::_movementController); localArms_ = rdp(m_, ctrl + off::PlayerController::_armsController); }
        p.actor = (int)rd32(m_, view + off::PhotonView::ownerActorNr);
        p.dead  = rd8(m_, ctrl + off::PlayerController::_isDeath) != 0;
        p.pos   = rdv<Vec3>(m_, net + off::PlayerNetwork::networkPosition);
        p.vel   = rdv<Vec3>(m_, net + off::PlayerNetwork::_remoteVelocity);
        {
            float q[4];                                   // networkRotation (x,y,z,w) -> yaw
            if (m_.read(net + off::PlayerNetwork::networkRotation, q, sizeof q) && std::isfinite(q[0]) && std::isfinite(q[1]) && std::isfinite(q[2]) && std::isfinite(q[3]))
                p.yaw = std::atan2(2.f * (q[3] * q[1] + q[0] * q[2]), 1.f - 2.f * (q[1] * q[1] + q[2] * q[2])) * 57.29578f;
        }
        p.crouch = (rd8(m_, net + off::PlayerNetwork::_appliedBools) & 2) != 0;   // PlayerNetwork.BoolCrouching
        uint64_t pl = rdp(m_, ctrl + off::PlayerController::_player);
        if (plausible_ptr(pl)) {
            std::string nm = il_.str(rdp(m_, pl + off::Player::nickName));
            strncpy(p.name, nm.c_str(), sizeof p.name - 1);
        }
        for (int a : mateActors) if (a == p.actor) p.mate = true;
        auto it = life.find(p.actor);
        if (it != life.end()) {
            p.hp = it->second.first;
            p.team = it->second.second;
            if (p.hp <= 0) p.dead = true;
        }
        if (!finite3(p.pos) || (p.pos.x == 0 && p.pos.y == 0 && p.pos.z == 0)) continue;   // not spawned yet
        if (!p.local) {
            // the body is drawn from an interpolation buffer, networkPosition is the newest sample (ahead of the body): take the rendered
            // camera pivot's world position instead; accept it only when it sits where a head over networkPosition should be
            bool ex = false;
            uint64_t pivot = rdp(m_, net + off::PlayerNetwork::_remoteCameraPivot);
            const double tn = now_s();
            if (plausible_ptr(pivot) && tn >= txOffUntil_) {
                Vec3 e;
                if (world_pos(pivot, e)) {
                    float dx = e.x - p.pos.x, dz = e.z - p.pos.z;
                    if (dx * dx + dz * dz < 16.f && e.y > p.pos.y - 0.6f && e.y < p.pos.y + 3.2f) {
                        float st = rdf(m_, net + off::PlayerNetwork::_remoteCamStandY), cr = rdf(m_, net + off::PlayerNetwork::_remoteCamCrouchY);
                        float view = p.crouch ? ((cr > 0.8f && cr < 2.2f) ? cr : 1.15f) : ((st > 0.8f && st < 2.2f) ? st : 1.6f);
                        float fy = e.y - view;
                        if (std::fabs(fy - p.pos.y) < 1.0f) p.pos.y = fy;
                        p.pos.x = e.x; p.pos.z = e.z;
                        ex = true; txOk_++;
                    } else txBad_++;
                } else txFail_++;
                if (txOk_ == 0 && txBad_ + txFail_ > 80) { txOffUntil_ = tn + 60.0; txBad_ = txFail_ = 0; }
            }
            if (!ex) {                                                // fallback: wind the network sample back by the interpolation delay
                float d = rdf(m_, net + off::PlayerNetwork::interpolationDelay);
                if (!(d > 0.01f && d < 0.5f)) d = 0.1f;
                p.pos.x -= p.vel.x * d; p.pos.z -= p.vel.z * d;
            }
            p.exact = ex;
        }
        if (p.local) { s.haveLocal = true; s.localActor = p.actor; s.localTeam = p.team; }
        s.players.push_back(p);
    }
    if (!s.haveLocal && localActorFromCtrl) {                    // local player is not in the culling list: take actor/team from the life table
        s.haveLocal = true; s.localActor = localActorFromCtrl;
        auto it = life.find(localActorFromCtrl);
        if (it != life.end()) s.localTeam = it->second.second;
    }
    read_bomb(s, serverTime);
    s.valid = true;
    status_ = "ok";
    return true;
}

// ---- weapon mods: zero a few managed floats of the (shared) weapon parameter objects, restore the originals when switched off
void Game::patch_weapons(bool noRecoil, bool noSpread) {
    const double t = now_s();
    if (t < nextWp_) return;
    nextWp_ = t + 1.0;
    if (!noRecoil && !noSpread && saved_.empty()) return;

    auto restore = [&](int cat) {
        for (size_t i = 0; i < saved_.size();) {
            if (saved_[i].cat == cat) {
                if (rdp(m_, saved_[i].obj) == saved_[i].klass) m_.write(saved_[i].addr, &saved_[i].bits, 4);   // dead / reused object: forget, never write into it
                saved_.erase(saved_.begin() + i);
            }
            else i++;
        }
    };
    if (!noRecoil) restore(1);
    if (!noSpread) restore(2);
    if (!noRecoil && !noSpread) return;

    // (re)find the WeaponParameters objects: once, and again when they vanished
    bool stale = wp_.empty();
    for (uint64_t o : wp_) if (rdp(m_, o) != kWp_) { stale = true; break; }
    if (stale && t >= nextWpScan_) {
        nextWpScan_ = t + 15.0;
        if (!kWp_) kWp_ = il_.klass(off::WeaponParameters::cls);
        wp_.clear();
        if (kWp_)
            wp_ = il_.find_instances(kWp_, [&](uint64_t o) { return plausible_ptr(rdp(m_, o + off::WeaponParameters::_recoilParameters)); });
    }
    auto zero = [&](uint64_t addr, int cat, uint64_t obj) {
        uint32_t cur = rd32(m_, addr);
        float f; memcpy(&f, &cur, 4);
        if (!std::isfinite(f) || f == 0.f) return;               // already zero (or garbage): nothing to do / nothing to save
        for (auto& s : saved_) if (s.addr == addr) return;
        uint32_t z = 0;
        if (m_.write(addr, &z, 4)) saved_.push_back({addr, cur, cat, obj, rdp(m_, obj)});
    };
    for (uint64_t o : wp_) {
        if (rdp(m_, o) != kWp_) continue;
        if (noSpread) { zero(o + off::WeaponParameters::_pelletSpread, 2, o); zero(o + off::WeaponParameters::_scopedMoveInaccuracy, 2, o); }
        if (noRecoil) {
            uint64_t rp = rdp(m_, o + off::WeaponParameters::_recoilParameters);
            if (!plausible_ptr(rp)) continue;
            zero(rp + off::RecoilParameters::_horizontalRange, 1, rp); zero(rp + off::RecoilParameters::_verticalRange, 1, rp);
            zero(rp + off::RecoilParameters::cameraDeviationCoeff, 1, rp); zero(rp + off::RecoilParameters::_viewKickAngle, 1, rp);
        }
    }
}

// ---- movement: bhop / speed / fly / noclip on the LOCAL PlayerMovement (PlayerController._movementController).
// The game runs a Source-style simulation (SourceGameMovement, 64 Hz ticks): its position/velocity live in `_core`, tuning in `_movement`.
// Slow path (4x/s): statics + tuning fields. Fast path (every loop): velocity writes. Everything we change is saved and put back,
// but only into objects that are still alive (klass word check) -- a respawn or scene change never makes us write into freed memory.
void Game::drive_move(const MoveCfg& c, const Snapshot& s) {
    const double t = now_s();
    if (!kMove_) kMove_ = il_.klass(off::PlayerMovement::cls);
    if (!kTun_)  kTun_  = il_.klass(off::SourceMovementTuning::cls);
    if (!kCore_) kCore_ = il_.klass(off::SourceGameMovement::cls);
    const uint64_t mv = localMove_;
    const bool alive = kMove_ && plausible_ptr(mv) && rdp(m_, mv) == kMove_;
    if (mv != mvOwner_) {                                   // new local object: its saved entries belong to freed memory -> drop them, no write
        for (auto it = mv_.begin(); it != mv_.end();) { if (it->second.obj) it = mv_.erase(it); else ++it; }
        mvOwner_ = mv; baseMax_ = 0; hopFloor_ = 0;
    }
    if (!c.any() && mv_.empty()) { mvDiag_ = alive ? "mv=1" : "mv=0"; return; }
    if (!alive) { mvDiag_ = kMove_ ? "mv=0(no local PlayerMovement)" : "mv=0(no PlayerMovement class)"; return; }

    auto live = [&](const MvSaved& e) { return e.obj == 0 || rdp(m_, e.obj) == e.klass; };
    auto setv = [&](uint64_t addr, int sz, uint32_t want, uint64_t obj, uint64_t klass) {
        uint32_t cur = 0;
        m_.read(addr, &cur, sz);
        if (sz == 1) cur &= 0xFF;
        if (cur == want) return;
        if (!mv_.count(addr)) mv_[addr] = {sz, cur, obj, klass};
        m_.write(addr, &want, sz);
    };
    auto unset = [&](uint64_t addr) {
        auto it = mv_.find(addr);
        if (it == mv_.end()) return;
        if (live(it->second)) m_.write(addr, &it->second.bits, it->second.size);
        mv_.erase(it);
    };
    auto fbits = [](float f) { uint32_t u; memcpy(&u, &f, 4); return u; };

    // ---- slow path
    if (t >= nextMv_) {
        nextMv_ = t + 0.25;
        if (uint64_t st = il_.statics(kMove_)) {                                   // AutoBunnyHopping / EnableBunnyHopping
            for (uint32_t o : {off::PlayerMovement::s_AutoBunnyHopping, off::PlayerMovement::s_EnableBunnyHopping}) {
                if (c.bhop) setv(st + o, 1, 1, 0, 0); else unset(st + o);
            }
        }
        tunOk_ = false;
        uint64_t tun = rdp(m_, mv + off::PlayerMovement::_movement);
        if (kTun_ && plausible_ptr(tun) && rdp(m_, tun) == kTun_) {
            if (baseMax_ <= 0) {
                uint64_t a = tun + off::SourceMovementTuning::MaxSpeed;
                uint32_t b = mv_.count(a) ? mv_[a].bits : rd32(m_, a);
                float f; memcpy(&f, &b, 4);
                if (std::isfinite(f) && f > 20.f && f < 5000.f) baseMax_ = f;
            }
            tunOk_ = true;
            struct F { uint32_t off; float val; };
            for (F f : {F{off::SourceMovementTuning::BunnyJumpMaxSpeedFactor, 100.f}, F{off::SourceMovementTuning::StaminaJumpCost, 0.f}, F{off::SourceMovementTuning::StaminaLandCost, 0.f}}) {
                if (c.bhop) setv(tun + f.off, 4, fbits(f.val), tun, kTun_); else unset(tun + f.off);
            }
            if (c.airStrafe > 1.001f) {
                for (uint32_t o : {off::SourceMovementTuning::AirAccelerate, off::SourceMovementTuning::AirWishSpeedCap}) {
                    uint64_t a = tun + o; uint32_t b0 = mv_.count(a) ? mv_[a].bits : rd32(m_, a); float f0; memcpy(&f0, &b0, 4);
                    if (std::isfinite(f0) && f0 > 0.f && f0 < 1000.f) setv(a, 4, fbits(f0 * c.airStrafe), tun, kTun_);
                }
            } else {
                unset(tun + off::SourceMovementTuning::AirAccelerate); unset(tun + off::SourceMovementTuning::AirWishSpeedCap);
            }
            uint64_t ms = tun + off::SourceMovementTuning::MaxSpeed;
            if (c.speed > 1.001f && baseMax_ > 0) setv(ms, 4, fbits(baseMax_ * c.speed), tun, kTun_); else unset(ms);
        }
        if (!kConv_) kConv_ = il_.klass(off::MovementConVars::cls);
        if (uint64_t cs = il_.statics(kConv_)) {                                   // convar override of the jump impulse (m/s)
            uint64_t a = cs + off::MovementConVars::s_JumpImpulse;
            if (c.jump > 1.001f || c.jump < 0.999f) setv(a, 4, fbits(7.5498347f * c.jump), 0, 0); else unset(a);
        }
        uint64_t nc = mv + off::PlayerMovement::NoclipEnabled;
        if (c.noclip) setv(nc, 1, 1, mv, kMove_); else unset(nc);
        { uint64_t ws = mv + off::PlayerMovement::_weaponSpeedScale; if (c.noWeaponSlow) setv(ws, 4, fbits(1.f), mv, kMove_); else unset(ws); }
        uint64_t gs = mv + off::PlayerMovement::_gravityScale;
        if (!c.fly && (c.grav < 0.999f)) setv(gs, 4, fbits(c.grav), mv, kMove_); else if (!c.fly) unset(gs);
    }

    // ---- fast path: velocity
    uint64_t core = rdp(m_, mv + off::PlayerMovement::_core);
    const bool coreOk = kCore_ && plausible_ptr(core) && rdp(m_, core) == kCore_;
    float sx = 0, sy = 0;
    {
        float a[2], b[2] = {0, 0};
        m_.read(mv + off::PlayerMovement::_wishStick, a, 8);
        m_.read(mv + off::PlayerMovement::_rawStick, b, 8);
        if (!std::isfinite(a[0]) || !std::isfinite(a[1])) a[0] = a[1] = 0;
        if (!std::isfinite(b[0]) || !std::isfinite(b[1])) b[0] = b[1] = 0;
        bool useRaw = (b[0] * b[0] + b[1] * b[1]) > (a[0] * a[0] + a[1] * a[1]);
        sx = useRaw ? b[0] : a[0]; sy = useRaw ? b[1] : a[1];
    }
    float mag = std::sqrt(sx * sx + sy * sy);
    if (mag > 1.f) { sx /= mag; sy /= mag; mag = 1.f; }
    const bool held = mag > 0.2f;
    Vec3 f3 = s.cam.fwd;
    Vec3 ff = norm(Vec3{f3.x, 0, f3.z});
    Vec3 rr{ff.z, 0, -ff.x};                                                       // Unity left-handed: right = (z, 0, -x) of the flat forward

    float vh = 0, vy = 0; bool og = false;
    if (coreOk) {
        Vec3 v = rdv<Vec3>(m_, core + off::SourceGameMovement::Velocity);
        if (finite3(v)) { vh = std::sqrt(v.x * v.x + v.z * v.z); vy = v.y; }
        og = rd8(m_, core + off::SourceGameMovement::OnGround) != 0;
    }
    uint64_t gs = mv + off::PlayerMovement::_gravityScale;
    if (c.fly && coreOk) {
        setv(gs, 4, 0, mv, kMove_);                                                // no gravity while flying
        Vec3 d = f3 * sy + rr * sx;
        Vec3 nv{};
        if (held) { d = norm(d); nv = d * (c.flySpeed * mag); }
        m_.write(core + off::SourceGameMovement::Velocity, &nv, sizeof nv);
    } else if (c.fly == false && mv_.count(gs) && c.grav >= 0.999f) {
        unset(gs);
    } else if (coreOk && held) {
        float floorv = 0;
        const bool ducked = rd8(m_, core + off::SourceGameMovement::Ducked) != 0 || rd8(m_, mv + off::PlayerMovement::_walkInput) != 0;
        if (c.speed > 1.001f && og && !ducked && baseMax_ > 0) floorv = baseMax_ * 0.025f * c.speed;      // 1 unit = 0.025 m
        if (c.bhop && c.bhopSpeed > 0.f) floorv = std::max(floorv, c.bhopSpeed * std::min(1.f, mag * 1.25f));
        if (floorv > 0.f && vh < floorv) {
            Vec3 wd = norm(ff * sy + rr * sx);
            float nx = wd.x * floorv, nz = wd.z * floorv;
            m_.write(core + off::SourceGameMovement::Velocity, &nx, 4);
            m_.write(core + off::SourceGameMovement::Velocity + 8, &nz, 4);
            hopFloor_ = floorv;
        }
    }
    // auto-hop: press jump ourselves the moment we are on the ground with the stick held
    if (c.bhop && coreOk && held && og) {
        uint8_t one = 1;
        m_.write(mv + off::PlayerMovement::_jumpPressPending, &one, 1);
    }
    if (c.infStamina) {
        uint64_t tun = rdp(m_, mv + off::PlayerMovement::_movement);
        float mx = (kTun_ && plausible_ptr(tun) && rdp(m_, tun) == kTun_) ? rdf(m_, tun + off::SourceMovementTuning::StaminaMax) : 0.f;
        if (std::isfinite(mx) && mx > 0.f && mx < 1000.f) m_.write(mv + off::PlayerMovement::_stamina, &mx, 4);
    }
    if (c.noFall) { uint32_t z = 0; m_.write(mv + off::PlayerMovement::_fallDamage, &z, 4); m_.write(mv + off::PlayerMovement::_fallVelocity, &z, 4); }
    char b[160];
    snprintf(b, sizeof b, "mv=1 core=%d tun=%d st=%.1f,%.1f vh=%.1f og=%d", coreOk ? 1 : 0, tunOk_ ? 1 : 0, sx, sy, vh, og ? 1 : 0);
    mvDiag_ = b;
    (void)vy;
}

std::string Game::local_diag() const {
    char b[96];
    snprintf(b, sizeof b, "ctrl=%d mv=%d arms=%d tx=%d/%d", localCtrl_ ? 1 : 0, localMove_ ? 1 : 0, localArms_ ? 1 : 0, txOk_, txBad_ + txFail_);
    return b;
}

// ---- code patches: `ret` at the entry of void functions. Addresses come from il2cpp's own method table (no RVAs).
void Game::patch_code(bool, bool) {
    // recoil/spread are data-only now (patch_weapons + patch_arms). Undo any ret patch left by an older build, once.
    if (code_retDone_) return;
    code_retDone_ = true;
    for (uint64_t a : {addrRecoil_, addrKick_, addrShake_, addrDisp_}) if (a && code_.has(a)) code_.restore(a);
}

// ---- arms state: magazine freeze (infinite ammo) and the penetration mask (wallbang)
void Game::patch_arms(bool infAmmo, bool wallbang, bool noRecoil) {
    if (!kArms_) kArms_ = il_.klass(off::ArmsController::cls);
    uint64_t a = localArms_;
    {
        char b[64];
        snprintf(b, sizeof b, "arms=%d", (kArms_ && plausible_ptr(a) && rdp(m_, a) == kArms_) ? 1 : 0);
        armsDiag_ = b;
    }
    if (!infAmmo && !wallbang && !noRecoil && ar_.empty()) return;
    if (a != armsOwner_) {                               // new local player object: forget old state, never write back to a dead object
        ar_.clear(); armsOwner_ = a; lastWeapon_ = -1; maxMag_ = 0;
    }
    if (!kArms_ || !plausible_ptr(a) || rdp(m_, a) != kArms_) return;
    if (infAmmo) {
        int w = (int)rd32(m_, a + off::ArmsController::_weaponId);
        int16_t mag = rdv<int16_t>(m_, a + off::ArmsController::MagazineCapacity);
        bool reloading = rd8(m_, a + off::ArmsController::isReload) != 0;
        if (w != lastWeapon_) { lastWeapon_ = w; maxMag_ = mag; }
        else if (mag > maxMag_) maxMag_ = mag;
        if (!reloading && mag >= 0 && mag < maxMag_ && maxMag_ <= 300) { int16_t v = (int16_t)maxMag_; m_.write(a + off::ArmsController::MagazineCapacity, &v, 2); }
    }
    {
        const uint32_t rm = off::ArmsController::_recoilMult;
        uint64_t ra = a + rm;
        if (noRecoil) {
            uint32_t cur = rd32(m_, ra); float f; memcpy(&f, &cur, 4);
            if (std::isfinite(f) && f != 0.f) { if (!ar_.count(ra)) ar_[ra] = {4, cur, a, kArms_}; uint32_t z = 0; m_.write(ra, &z, 4); }
            uint32_t z = 0;                                            // accumulated camera recoil / kick: keep at zero
            for (uint32_t o : {0x154u, 0x158u, 0x16Cu, 0x170u}) { float cf; m_.read(a + o, &cf, 4); if (std::isfinite(cf) && cf != 0.f) m_.write(a + o, &z, 4); }
        } else if (ar_.count(ra)) { if (rdp(m_, a) == kArms_) m_.write(ra, &ar_[ra].bits, 4); ar_.erase(ra); }
    }
    uint64_t sm = a + off::ArmsController::shotThroughMask;
    if (wallbang) {
        uint32_t cur = rd32(m_, sm);
        if (cur != 0xFFFFFFFFu) { if (!ar_.count(sm)) ar_[sm] = {4, cur, a, kArms_}; uint32_t all = 0xFFFFFFFFu; m_.write(sm, &all, 4); }
    } else if (ar_.count(sm)) { if (rdp(m_, a) == kArms_) m_.write(sm, &ar_[sm].bits, 4); ar_.erase(sm); }
}

// ---- silent aim detour management
static std::string tidy(std::string s) { for (auto& ch : s) if (ch == ' ' || ch == '|' || ch == ',' || ch == ';') ch = '_'; return s.substr(0, 42); }

void Game::silent_prepare(bool wanted) {
    const double t = now_s();
    if (!wanted) {
        if (fire_.ready() || pell_.ready()) { fire_.uninstall(); pell_.uninstall(); fireOk_ = pellOk_ = false; }
        silentStatus_ = "off";
        return;
    }
    if (fireOk_) return;
    if (t < nextSilent_) return;
    nextSilent_ = t + 3.0;
    if (!kArms_) kArms_ = il_.klass(off::ArmsController::cls);
    if (!kArms_) { silentStatus_ = "no_ArmsController_class"; return; }
    uint64_t fr = il_.method_addr(kArms_, "FireRay", 4), fp = il_.method_addr(kArms_, "FirePellets", 5);
    if (!fr) { silentStatus_ = "FireRay_not_found"; return; }
    std::string err;
    fireOk_ = fire_.install(fr, 3, err);
    if (!fireOk_) { silentStatus_ = "err_" + tidy(err); return; }
    pellOk_ = fp && pell_.install(fp, 4, err);
    silentStatus_ = pellOk_ ? "ok" : "ok_ray_only";
}

void Game::silent_feed(bool on, Vec3 dir) {
    if (!fireOk_) return;
    if (!on) { fire_.off(); if (pellOk_) pell_.off(); return; }
    if (plausible_ptr(localArms_) && kArms_ && rdp(m_, localArms_) == kArms_) {      // shots fired while armed (ArmsController._timeFired 0x144 changes per shot)
        uint32_t tf = rd32(m_, localArms_ + 0x144);
        if (tf != lastTimeFired_ && lastTimeFired_ != 0) shotsArmed_++;
        lastTimeFired_ = tf;
    }
    uint64_t deadline = counter_now() + counter_freq() / 8;          // 125 ms: the detour switches itself off if we stop feeding
    float d[3] = {dir.x, dir.y, dir.z};
    fire_.feed(d, deadline);
    if (pellOk_) { float q[4]; look_quat(dir, q); pell_.feed(q, deadline); }
}

void Game::shutdown_patches() {
    fire_.uninstall(); pell_.uninstall(); fireOk_ = pellOk_ = false;
    code_.restore_all();
    for (auto& kv : mv_) if (kv.second.obj == 0 || rdp(m_, kv.second.obj) == kv.second.klass) m_.write(kv.first, &kv.second.bits, kv.second.size);
    mv_.clear();
    for (auto& kv : ar_) if (rdp(m_, kv.second.obj) == kv.second.klass) m_.write(kv.first, &kv.second.bits, kv.second.size);
    ar_.clear();
    for (auto& sv : saved_) if (rdp(m_, sv.obj) == sv.klass) m_.write(sv.addr, &sv.bits, 4);
    saved_.clear();
}
